﻿using CrudOperation.CommonLayer.Model;
using System.Data;
using System.Data.SqlClient;
using System.Linq.Expressions;

namespace CrudOperation.RepositoryLayer
{
    public class CrudOperationRL : ICrudOperationRL
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _sqlConnection;
        public CrudOperationRL(IConfiguration configuration)
        {
            _configuration = configuration;
            _sqlConnection = new SqlConnection(_configuration[key: "ConnectionStrings:DBSettingConnection"]);
        }
        public async Task<CreateRecordResponse> CreateRecord(CreateRecordRequest request)
        {
            CreateRecordResponse response = new CreateRecordResponse();

            try
            {
                using (SqlConnection connectionsting = new SqlConnection(_sqlConnection.ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("InsertCrudOperation", connectionsting))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = request.username;
                        cmd.Parameters.Add("@Age", SqlDbType.VarChar).Value = request.Age;

                        connectionsting.Open();
                        int status = await cmd.ExecuteNonQueryAsync();

                        if (status == 0)
                        {
                            response.IsSucess = false;
                            response.Message = "Something Went Wrong";
                        }
                        else
                        {
                            response.IsSucess = true;
                            response.Message = "Successful";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSucess = false;
                response.Message = "UnSuccessful";
            }

            return response;
        }

        public async Task<ReadRecordResponse> SelectRecord()
        {
            ReadRecordResponse response = new ReadRecordResponse();

            try
            {
                using (SqlConnection connectionsting = new SqlConnection(_sqlConnection.ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("SelCrudOperation", connectionsting))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        connectionsting.Open();

                        using (SqlDataReader sqlDataReader = await cmd.ExecuteReaderAsync())
                        {
                            if (sqlDataReader.HasRows)
                            {
                                response.ReadRecordData = new List<ReadRecordData>();

                                while (await sqlDataReader.ReadAsync())
                                {
                                    ReadRecordData dbdata = new ReadRecordData();
                                    dbdata.Id = sqlDataReader[name: "Id"] != DBNull.Value ? Convert.ToInt32(sqlDataReader[name: "Id"]) : 0;
                                    dbdata.UserName = sqlDataReader[name: "UserName"] != DBNull.Value ? Convert.ToString(sqlDataReader[name: "UserName"]) : string.Empty;
                                    dbdata.Age = sqlDataReader[name: "Age"] != DBNull.Value ? Convert.ToInt32(sqlDataReader[name: "Age"]) : 0;
                                    response.ReadRecordData.Add(dbdata);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "UnSuccessful";
            }

            return response;
        }

        public async Task<UpdateRecordResponse> UpdateRecord(UpdateRecordRequest request)
        {
            UpdateRecordResponse response = new UpdateRecordResponse();

            try
            {
                using (SqlConnection connectionsting = new SqlConnection(_sqlConnection.ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateCrudOperation", connectionsting))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Id", SqlDbType.VarChar).Value = request.Id;
                        cmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = request.username;
                        cmd.Parameters.Add("@Age", SqlDbType.VarChar).Value = request.Age;

                        connectionsting.Open();
                        int status = await cmd.ExecuteNonQueryAsync();

                        if (status == 0)
                        {
                            response.IsSucess = false;
                            response.Message = "Something Went Wrong";
                        }
                        else
                        {
                            response.IsSucess = true;
                            response.Message = "Successful";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSucess = false;
                response.Message = "UnSuccessful";
            }

            return response;
        }

        public async Task<DeleteRecordResponse> DeleteRecord(DeleteRecordRequest request)
        {
            DeleteRecordResponse response = new DeleteRecordResponse();

            try
            {
                using (SqlConnection connectionsting = new SqlConnection(_sqlConnection.ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("DeleteCrudOperation", connectionsting))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Id", SqlDbType.VarChar).Value = request.Id;

                        connectionsting.Open();
                        int status = await cmd.ExecuteNonQueryAsync();

                        if (status == 0)
                        {
                            response.IsSucess = false;
                            response.Message = "Something Went Wrong";
                        }
                        else
                        {
                            response.IsSucess = true;
                            response.Message = "Successful";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSucess = false;
                response.Message = "UnSuccessful";
            }

            return response;
        }
    }
}
