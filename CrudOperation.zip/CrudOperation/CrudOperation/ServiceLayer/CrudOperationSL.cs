﻿using CrudOperation.CommonLayer.Model;
using CrudOperation.RepositoryLayer;
using System.Runtime.InteropServices;

namespace CrudOperation.ServiceLayer
{
    public class CrudOperationSL : ICrudOperationSL
    {
        public readonly ICrudOperationRL _crudOperationRL;

        public CrudOperationSL(ICrudOperationRL crudOperationRL)
        {
            _crudOperationRL= crudOperationRL;
        }
        public async Task<CreateRecordResponse> CreateRecord(CreateRecordRequest createRecordRequest)
        {
            return await _crudOperationRL.CreateRecord(createRecordRequest);
        }

        public Task<UpdateRecordResponse> CreateRecord(UpdateRecordRequest request)
        {
            throw new NotImplementedException();
        }

        public Task<ReadRecordResponse> SelectRecord()
        {
            return _crudOperationRL.SelectRecord();
        }

        public Task<UpdateRecordResponse> UpdateRecord(UpdateRecordRequest request)
        {
            return _crudOperationRL.UpdateRecord(request);
        }

        public Task<DeleteRecordResponse> DeleteRecord(DeleteRecordRequest request)
        {
            return _crudOperationRL.DeleteRecord(request);
        }
    }
}
