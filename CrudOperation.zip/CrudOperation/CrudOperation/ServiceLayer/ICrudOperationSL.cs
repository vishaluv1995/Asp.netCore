﻿using CrudOperation.CommonLayer.Model;

namespace CrudOperation.ServiceLayer
{
    public interface ICrudOperationSL
    {
        public Task<CreateRecordResponse> CreateRecord(CreateRecordRequest createRecordRequest);
        public Task<ReadRecordResponse> SelectRecord();
        public Task<UpdateRecordResponse> UpdateRecord(UpdateRecordRequest request);
        public Task<DeleteRecordResponse> DeleteRecord(DeleteRecordRequest request);

    }
}
