﻿namespace CrudOperation.CommonLayer.Model
{
    public class UpdateRecordRequest
    {
        public int Id { get; set; }
        public string username { get; set; }
        public int Age { get; set; }
    }

    public class UpdateRecordResponse
    {
        public bool IsSucess { get; set; }
        public string Message { get; set; }
    }
}
