﻿namespace CrudOperation.CommonLayer.Model
{
    public class CreateRecordRequest
    {
        public string username { get; set; }
        public int Age { get; set; }
    }

    public class CreateRecordResponse
    {
        public bool IsSucess { get; set; }
        public string Message { get; set; }
    }
}
