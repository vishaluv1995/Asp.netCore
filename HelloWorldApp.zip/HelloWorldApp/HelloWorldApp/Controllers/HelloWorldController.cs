﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace HelloWorldApp.Controllers
{
    [EnableCors("AllowAllOrigins")]
    [Route("api/[controller]")]
    [ApiController]
    public class HelloWorldController : Controller
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Hello World! This is from ASP.NET Core!");
        }
    }
}