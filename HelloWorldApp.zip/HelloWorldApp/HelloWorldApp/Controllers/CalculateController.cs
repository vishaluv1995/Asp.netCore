﻿using Microsoft.AspNetCore.Mvc;

namespace HelloWorldApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CalculateController : ControllerBase
    {
        [HttpGet]
        public int Addtwonumber(int a, int b)
        {
            return a + b;
        }
    }
}


